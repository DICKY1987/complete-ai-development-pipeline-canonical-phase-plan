"""Package for the ledger_view module."""
